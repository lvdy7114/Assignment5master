package com.meritamerica.assignment5.controller;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.meritamerica.assignment5.AccountHolder;
import com.meritamerica.assignment5.CDOffering;
import com.meritamerica.assignment5.MeritBank;
import com.meritamerica.assignment5.exceptions.ExceedsCombinedBalanceLimitException;
import com.meritamerica.assignment5.exceptions.NotFoundException;
import com.meritamerica.assignment5.models.BankAccount;
import com.meritamerica.assignment5.models.CDAccount;
import com.meritamerica.assignment5.models.CheckingAccount;
import com.meritamerica.assignment5.models.SavingsAccount;

@RestController
public class MeritBankController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass() );
	
	//controller for AccountHolders
	
	//@RequestMapping (value = "/AccountHolders", method = RequestMethod.GET)
	@PostMapping(value = "/AccountHolders")
	@ResponseStatus(HttpStatus.CREATED)
	public AccountHolder loadAccountHolder( @Valid @RequestBody  AccountHolder ah) {
		MeritBank.addAccountHolder(ah);
		return ah;
	}
	
	@GetMapping(value = "/AccountHolders")
	public List<AccountHolder> getAccountHolders(){
		return MeritBank.getAccountHolders();
	}
	
	@GetMapping(value = "/AccountHolders/{id}")
	public AccountHolder getAccountHolderByID(@PathVariable (name = "id") long id) throws NotFoundException {
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		
		return ah;
	}
	
	@PostMapping(value = "/AccountHolders/{id}/CheckingAccounts")
	@ResponseStatus(HttpStatus.CREATED)
	public CheckingAccount addCheckingAccount(@PathVariable(name = "id") long id, @Valid @RequestBody  CheckingAccount ch) 
				throws NotFoundException, ExceedsCombinedBalanceLimitException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		ah.addCheckingAccount(ch);
		return ch;
	}
	
	
	@GetMapping(value = "/AccountHolders/{id}/CheckingAccounts")
	public List<BankAccount> getCheckingAccounts(@PathVariable(name = "id") long id) 
				throws NotFoundException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		return ah.getCheckingAccounts();
	} 

	
	@PostMapping(value = "/AccountHolders/{id}/SavingsAccounts")
	@ResponseStatus(HttpStatus.CREATED)
	public SavingsAccount addSavingsAccount(@PathVariable(name = "id") long id, @Valid @RequestBody  SavingsAccount sa) 
				throws NotFoundException, ExceedsCombinedBalanceLimitException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		ah.addSavingsAccount(sa);
		return sa;
	}
	
	
	@GetMapping(value = "/AccountHolders/{id}/SavingsAccounts")
	public List<BankAccount> getSavingsAccounts(@PathVariable(name = "id") long id) 
				throws NotFoundException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		return ah.getSavingsAccounts();
	} 
	
	
	@PostMapping(value = "/AccountHolders/{id}/CDAccounts")
	@ResponseStatus(HttpStatus.CREATED)
	public CDAccount addCDAccount(@PathVariable(name = "id") long id, @Valid @RequestBody  CDAccount cd) 
				throws NotFoundException, ExceedsCombinedBalanceLimitException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		ah.addCDAccount(cd);
		return cd;
	}
	

	@GetMapping(value = "/AccountHolders/{id}/CDAccounts")
	public List<BankAccount> getCDAccounts(@PathVariable(name = "id") long id) 
				throws NotFoundException {
		
		AccountHolder ah = MeritBank.getAccountHolderByID(id);
		return ah.getCDAccounts();
	} 
	
	//controllers for CDOfferings
	@PostMapping(value = "/CDOfferings")
	@ResponseStatus(HttpStatus.CREATED)
	public CDOffering createCDOffering(@Valid @RequestBody CDOffering cdo) {
		MeritBank.addCDOffering(cdo);
		return cdo;
	}
	

	@GetMapping(value = "/CDOfferings")
	public List<CDOffering> getCDOfferings() throws NotFoundException {
		List<CDOffering> cdo = MeritBank.getCDOfferings();
		return cdo;
	}
	
	
	
	
}
